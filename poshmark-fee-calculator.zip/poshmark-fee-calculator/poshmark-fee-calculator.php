<?php
/*
Plugin Name: Poshmark Fee Calculator Shortcode
Plugin URI: https://sellercave.com/poshmark-fee-calculator/
Description: Shortcode [poshmark_fee_calculator] — responsive Poshmark fee calculator. Inherits theme colors & typography via CSS variables.
Version: 1.0.1
Author: Sohaib S. Khan
Author URI: https://isohaibkhan.github.io/
Text Domain: poshmark-fee-calculator
*/

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

function poshmark_register_assets() {
    wp_register_style('poshmark-fee-calculator-css', plugins_url('assets/css/poshmark-fee-calculator.css', __FILE__));
    wp_register_script('poshmark-fee-calculator-js', plugins_url('assets/js/poshmark-fee-calculator.js', __FILE__), array('jquery'), '1.0', true);

    // Rates and currency mapping passed to JS. Filterable via 'poshmark_calc_rates'.
    $rates = array(
        'United States' => array(
            'currency' => '$',
            'code' => 'USD',
            // Poshmark selling fee is 20% of sale price
            'poshFee' => array('rate' => 0.20),
        ),
        'Canada' => array(
            'currency' => 'C$',
            'code' => 'CAD',
            'poshFee' => array('rate' => 0.20),
        ),
    );

    $rates = apply_filters('poshmark_calc_rates', $rates);

    wp_localize_script('poshmark-fee-calculator-js', 'PoshmarkCalcData', array(
        'rates' => $rates,
        'strings' => array(
            'poshInfo' => "Poshmark charges a 20% selling fee on all sales.",
        )
    ));
}
add_action('wp_enqueue_scripts', 'poshmark_register_assets');

function poshmark_fee_calculator_shortcode($atts = array()){
    // Enqueue when shortcode is used
    wp_enqueue_style('poshmark-fee-calculator-css');
    wp_enqueue_script('poshmark-fee-calculator-js');

    ob_start();
    ?>
    <div class="poshmark-calc" aria-live="polite">
        <div class="card">
            <!--
            <div class="top-row">
                <label class="label">Your Email <span class="required">*</span></label>
                <div class="email-row">
                    <div class="email-input-wrap">
                        <span class="email-icon">✉️</span>
                        <input id="poshmark-email" type="email" placeholder="you@example.com" aria-label="Your email" />
                    </div>
                    <button id="poshmark-confirm-email" class="btn" type="button">Confirm Email</button>
                    <button id="poshmark-clear" class="btn btn-outline" type="button">Clear All</button>
                </div>
                <p class="help-text">Required for your fee calculation</p>
            </div>
            -->

            <div class="grid">
                <div class="form-group">
                    <label>Country</label>
                    <select id="poshmark-country">
                        <option>United States</option>
                        <option>Canada</option>
                    </select>
                </div>

                <div class="form-group">
                    <label>Item Sale Price</label>
                    <input id="poshmark-sale-price" type="number" min="0" step="0.01" />
                </div>

                <div class="form-group">
                    <label>Item Cost</label>
                    <input id="poshmark-item-cost" type="number" min="0" step="0.01" />
                </div>
            </div>

            <div class="results" id="poshmark-results" aria-hidden="true">
                <div class="result-row"><div class="label">Poshmark Fee (20%):</div><div class="value" id="res-poshfee">-</div></div>
                <div class="result-row total"><div class="label">Total Fees:</div><div class="value" id="res-total">-</div></div>
                <div class="result-row"><div class="label">Your Earnings:</div><div class="value" id="res-earnings">-</div></div>
                <div class="result-row"><div class="label">Your Profit:</div><div class="value" id="res-profit">-</div></div>
                <div class="result-row"><div class="label">Profit Margin:</div><div class="value" id="res-margin">-</div></div>
            </div>
        </div>

        <!-- Modal for posh info -->
        <div id="poshmark-modal" class="modal" role="dialog" aria-modal="true" aria-hidden="true">
            <div class="modal-content">
                <button id="poshmark-modal-close" class="modal-close" aria-label="Close">×</button>
                <p id="poshmark-modal-text"><?php echo esc_html( "Poshmark charges a 20% selling fee on all sales." ); ?></p>
            </div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('poshmark_fee_calculator', 'poshmark_fee_calculator_shortcode');
