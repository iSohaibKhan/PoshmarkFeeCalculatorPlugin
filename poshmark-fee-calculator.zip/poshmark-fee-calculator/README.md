## README / Notes

* **Shortcode**: use `[poshmark_fee_calculator]` in any post/page/widget (text/html) to show the calculator.
* **Behavior**:

  * Email confirm required before inputs enable (same UX as Depop plugin).
  * Currency and fee rate come from the `poshmark_calc_rates` mapping and can be filtered.
  * Poshmark fee = **20% of item sale price** (adjustable via filter if needed).
  * **Profit Margin** is calculated as `profit / earnings * 100` to match the reference screenshot (so margin = Profit ÷ Earnings, not Profit ÷ Sale Price).
* **Design & theme integration**: CSS intentionally uses `font-family: inherit; color: inherit;` and CSS variables so button color/typography follow the theme/Elementor.
* You can change default rates by adding a filter in your theme's `functions.php`: