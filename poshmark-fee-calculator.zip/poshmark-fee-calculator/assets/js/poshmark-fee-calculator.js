(function(){
    function qs(sel, el) { return (el || document).querySelector(sel); }
    var rates = (window.PoshmarkCalcData && window.PoshmarkCalcData.rates) ? window.PoshmarkCalcData.rates : {};
    var strings = (window.PoshmarkCalcData && window.PoshmarkCalcData.strings) ? window.PoshmarkCalcData.strings : {};

    document.addEventListener('DOMContentLoaded', function(){
        var root = qs('.poshmark-calc');
        if(!root) return;

        // --- Email-related elements (no longer needed) ---
        /*
        var email = qs('#poshmark-email', root);
        var confirmBtn = qs('#poshmark-confirm-email', root);
        var clearBtn = qs('#poshmark-clear', root);
        */

        var inputs = [
            qs('#poshmark-country', root),
            qs('#poshmark-sale-price', root),
            qs('#poshmark-item-cost', root)
        ];

        var results = qs('#poshmark-results', root);
        var resPosh = qs('#res-poshfee', root);
        var resTotal = qs('#res-total', root);
        var resEarnings = qs('#res-earnings', root);
        var resProfit = qs('#res-profit', root);
        var resMargin = qs('#res-margin', root);

        var modal = qs('#poshmark-modal', root);
        var modalClose = qs('#poshmark-modal-close', root);
        var modalText = qs('#poshmark-modal-text', root);

        modalClose.addEventListener('click', function(){ modal.style.display='none'; modal.setAttribute('aria-hidden','true'); });
        modal.addEventListener('click', function(e){ if(e.target === modal){ modal.style.display='none'; modal.setAttribute('aria-hidden','true'); } });

        // --- Email dependency removed ---
        /*
        function setDisabledState(disabled){
            inputs.forEach(function(i){ if(i){ i.disabled = disabled; } });
            if(disabled){ root.classList.add('poshmark-disabled'); results.style.display = 'none'; }
            else { root.classList.remove('poshmark-disabled'); results.style.display = 'block'; }
        }

        // Initially disabled until email confirmed
        setDisabledState(true);

        confirmBtn.addEventListener('click', function(){
            var val = email.value.trim();
            if(!val || !/\S+@\S+\.\S+/.test(val)){
                alert('Please enter a valid email to continue');
                return;
            }
            confirmBtn.textContent = '✔ Email Confirmed';
            confirmBtn.disabled = true;
            setDisabledState(false);
            calculate();
        });

        clearBtn.addEventListener('click', function(){
            email.value = '';
            confirmBtn.textContent = 'Confirm Email';
            confirmBtn.disabled = false;
            inputs.forEach(function(i){ if(i){ if(i.type === 'checkbox') i.checked = false; else i.value = ''; } });
            setDisabledState(true);
            [resPosh,resTotal,resEarnings,resProfit,resMargin].forEach(function(el){ el.textContent='-'; el.classList.remove('positive','negative'); });
        });
        */

        // --- Now fields are enabled from the start ---
        results.style.display = 'block';

        inputs.forEach(function(i){ if(!i) return; i.addEventListener('input', calculate); i.addEventListener('change', calculate); });

        function formatCurrency(val, symbol){
            if(isNaN(val)) return '-';
            var fixed = Number(val).toFixed(2);
            return symbol + fixed;
        }

        function calculate(){
            var country = (qs('#poshmark-country', root).value || 'United States');
            var sale = parseFloat(qs('#poshmark-sale-price', root).value) || 0;
            var itemCost = parseFloat(qs('#poshmark-item-cost', root).value) || 0;

            var rateObj = rates[country] || rates['United States'];
            var currency = (rateObj && rateObj.currency) ? rateObj.currency : '$';
            var poshRate = (rateObj && rateObj.poshFee && rateObj.poshFee.rate) ? parseFloat(rateObj.poshFee.rate) : 0.20;

            var poshFee = Number((sale * poshRate).toFixed(2));
            var totalFees = poshFee;
            var earnings = Number((sale - poshFee).toFixed(2));
            var profit = Number((earnings - itemCost).toFixed(2));
            var margin = 0;
            if(earnings !== 0){ margin = Number(((profit / earnings) * 100).toFixed(1)); }

            resPosh.textContent = formatCurrency(poshFee, currency);
            resTotal.textContent = formatCurrency(totalFees, currency);
            resEarnings.textContent = formatCurrency(earnings, currency);
            resProfit.textContent = formatCurrency(profit, currency);
            resMargin.textContent = margin + '%';

            [resEarnings,resProfit].forEach(function(el){ 
                el.classList.remove('positive','negative'); 
                var num = parseFloat(el.textContent.replace(/[^0-9.-]+/g,'')); 
                if(!isNaN(num) && num >= 0) el.classList.add('positive'); 
                else el.classList.add('negative'); 
            });
        }

    });
})();
